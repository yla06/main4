<hr />footer
<hr />
<a href="?module=index">Главная</a>
<a href="?module=about">О нас</a>
<a href="?module=contact">Контакты</a>
<a href="?module=catalog">Каталог</a>
<a href="?module=product">Наш продукт</a>